---
name: editorial-hero-illustration
description: develop metaphor-driven hero illustrations for essays, articles, reports, talks, newsletters, and blog posts through a staged collaborative process. use when the user wants illustration concepts, visual metaphors, art-direction choices, refinement of an existing idea, a detailed image-generation prompt, rendering of an approved concept, revision of a generated image, or concise alt text. optimize for at-a-glance comprehension, editorial judgment, composition, internal visual logic, and deliberate style selection without imposing a single brand, medium, or visual universe.
---

# Editorial Hero Illustration

Turn the central relationship in a piece of writing into a memorable hero image. Preserve the conversation as part of the craft; do not compress all creative choices into a one-shot result.

Read [references/design-language.md](references/design-language.md) before proposing concepts or writing a prompt. Read [references/prompt-patterns.md](references/prompt-patterns.md) when composing the final image prompt or diagnosing a failed render.

## Governing idea

Find the image hiding underneath the argument.

Do not merely depict the subject matter. Make the underlying relationship visible: what diverges, collides, waits, bottlenecks, remains exposed, becomes complete, changes state, or reveals a hidden constraint.

Optimize for **at-a-glance comprehension**. The viewer should grasp the central idea before noticing atmosphere, craft, references, or secondary jokes.

Treat this pattern language as a lens, not a cage. Prefer a fresh, divergent, hybrid, or emergent idea whenever it better serves the story.

## Infer the current stage

Continue from the conversation's actual stage and perform only the next useful move.

1. **Draft received, no concept yet** — identify the editorial center and pitch two to four strong metaphor families.
2. **User already has a concept** — validate and sharpen it; do not reopen ideation unnecessarily.
3. **Family selected** — refine within that family rather than jumping to unrelated ideas.
4. **Concept settled** — write a composition-first rendering prompt and invite feedback.
5. **Prompt approved** — wait for explicit authorization such as “render it.”
6. **Image rendered** — assess or revise only when asked or when the user flags a problem.
7. **Image accepted** — provide one concise alt-text sentence.

Never render during stages 1–4. Treat “render it” as a quality gate.

## 1. Find the editorial center

Read the full text and identify:

- the underlying relationship, not merely the incident or topic;
- the editorial observation: what is surprising, paradoxical, funny, moving, or revealing;
- where scarcity, risk, tension, or leverage lives;
- which aspect of the piece should be foregrounded;
- whether the strongest image shows failure, the instant before failure, successful recovery, or a functioning system revealing its next constraint.

Ask internally:

- If this principle were a place one could walk into, what place would it be?
- If it were a familiar social ritual, what interaction would reveal it?
- What state, force, transition, or relationship should become visible?
- What should the viewer understand before reading the headline?

Do not confuse novelty with quality. Familiar metaphors are useful when matched precisely.

## 2. Establish art direction

Infer from the user's context, existing publication, sample images, or explicit preferences:

- medium: editorial cartoon, collage, diagrammatic illustration, painterly image, photographic concept, paper cutout, engraving, poster, or another form;
- aspect ratio and placement;
- audience and publication context;
- emotional register;
- desired density and level of abstraction;
- brand or series conventions;
- whether visible text is allowed.

Ask one focused question only when a missing choice would materially change the concept. Otherwise make a grounded recommendation and state the assumption briefly.

Do not impose a hand-drawn cartoon style, landscape format, warm tone, or specific character language unless the user requests it or the context supports it.

## 3. Explore or validate metaphor families

When the user has no concept, usually pitch **two to four** developed candidates rather than an indiscriminate list.

For each candidate, explain briefly:

- the physical, social, or symbolic world;
- the central contradiction or editorial observation;
- what aspect of the piece it foregrounds;
- how the viewer discovers the idea in the first two seconds;
- the main compositional risk.

When two concepts encode different truths, compare those truths rather than ranking generic visual strength.

When the user supplies a concept, treat it as a design hypothesis. Stress-test silent readability, emotional tone, composition, cultural associations, and internal logic. Preserve it when it works.

## 4. Refine within the chosen family

Treat the user's response as art direction, not a binary vote.

Refine by:

- simplifying to one dominant relationship;
- choosing the exact narrative instant;
- deciding whether the image is an action scene, social ritual, layered environment, portrait, diagrammatic metaphor, or quiet mise en scène;
- clarifying camera placement and eye path;
- preserving meaningful levels of agency or delegation;
- deciding what belongs in foreground, middle ground, and background;
- replacing technical jargon with ordinary physical experience when that broadens comprehension;
- deciding density: punch, layered, or exploratory.

Default to punch or restrained layered density. Use exploratory density only when lingering discovery is part of the intended experience.

## 5. Design the first two seconds

Before prompting, determine the reading sequence:

1. What is seen first?
2. What relationship becomes apparent next?
3. What delayed realization completes the idea?

The core concept must survive a thumbnail view or squint test. Secondary discoveries may reward attention but must not be required for comprehension.

## 6. Enforce an economy budget

Define a visual inventory:

- one dominant relationship or object;
- one primary action or contradiction;
- zero to three supporting details that reinforce the same thesis;
- one coherent setting;
- only the characters required for legibility.

Remove anything that merely proves the source text was read. Do not illustrate every paragraph, subplot, stakeholder, or consequence.

If the image cannot be described in one sentence with one main verb, simplify again.

## 7. Write a composition-first prompt

Write enough detail to lock the essential geometry without smothering the image. Composition matters more than adjective accumulation.

Include:

- **Editorial observation** — one sentence.
- **Scene** — one coherent physical, social, or symbolic world.
- **Characters and roles** — only essential actors, each with a distinct action.
- **Composition and camera** — focal point, eye path, scale, negative space, foreground/middle/background.
- **Narrative instant** — before, during, or after the crucial action.
- **Internal logic** — origins, trajectories, supports, connections, openings, and destinations must make sense.
- **Economy budget** — what must appear and what should be omitted.
- **Tone and density** — emotional register and punch/layered/exploratory mode.
- **Style direction** — medium, visual references, palette, line, texture, lighting, or photographic treatment as appropriate.
- **Exclusions** — likely failure modes, unwanted clichés, illegible text, duplicated objects, or irrelevant decoration.

Present the prompt for review. Do not render yet.

## 8. Render only on command

Call the image-generation tool only after explicit authorization. Use the full accumulated concept and art direction, not merely the user's latest short phrase.

After rendering, let the image stand unless the user asks for commentary.

## 9. Revise from the existing image

When the user requests a correction, preserve everything not named for change. Prefer editing the existing image when the metaphor and composition remain sound.

If the failure is structural—impossible geometry, confused eye path, wrong focal relationship, or a scene that no longer carries the idea—redesign the composition and write a revised prompt before rendering again.

Check for common failures:

- an object appears to originate from nowhere;
- motion runs in contradictory directions;
- multiple openings, paths, or focal points compete;
- decorative scenery becomes the subject;
- a key object transforms into a different kind of object;
- text becomes garbled or explanatory;
- secondary detail competes with the central relationship;
- the viewer must debug the image before understanding it.

## Pre-render review

Check:

1. Does the image express the underlying relationship rather than recap events?
2. Is the editorial observation clear?
3. Is there one first thing to notice?
4. Does it read at thumbnail size?
5. Is the two-second discovery sequence designed?
6. Does every major object obey the scene's internal logic?
7. Does the metaphor work for the intended audience?
8. Is the density intentional?
9. Is every supporting detail serving the same thesis?
10. Can any object, label, character, or background feature be removed?
11. Does the chosen style fit the publication rather than defaulting to generic AI polish?
12. Is there still room for a better emergent idea?

## Alt text

After acceptance, write one concrete sentence, usually 15–35 words. Describe the visible action and, when useful, the metaphor it conveys. Do not inventory the scene or over-explain the article.
